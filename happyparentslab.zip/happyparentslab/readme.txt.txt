# Happy Parents Lab Django App

This is a Django application for the Happy Parents Lab project.

## Getting Started

These instructions will help you set up and run the Django app locally.

### Prerequisites

- Docker
- Docker Compose

#### Housekeeping Points

- The focus is on the main flow, may not follow some standard practices.

##### Program Organization

- HAPPYPARENTSLAB/
├── happyparentslab/
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── cusotmer_orders/
│   ├── __init__.py
│   ├── models.py
│   ├── views.py
│   └── apps.py
│   └── admin.py
│   └── tests.py
├── manage.py
├── Dockerfile
└── requirements.txt
└── docker-compose.yml

###### Steps for deploying Docker Container
1. Open PowerShell in Admin Mode
2. Run cmd docker --version 
3. Navigate to the path where you have downloaded the Program Organization in Powershell
4. run cmd docker-compose up -d (Build and run the container using Docker Compose)
5. run cmd docker-compose exec web python manage.py migrate (Apply the database migrations)
6. run cmd docker-compose exec web python manage.py createsuperuser ( Create a superuser to access the Django admin )
7. run cmd docker-compose up
8. Access the Django app in your web browser at http://localhost:8000

####### Getting started
Access the application: 
	Open your web browser and visit http://localhost:8000 You should see the Django app running.
Access the Django admin:
	Open your web browser and visit http://localhost:8000/admin Log in using the superuser credentials created in the previous step.
Test Excel File:
	Test Excel File is included in the package
Download Option:
	Download for data and any editing can be done on the admin portal, select the Database and you will see a dropdown to download the data on your local PC
For accessing data through PowerShell:
	1. run cmd docker-compose exec db psql -U postgres -d happyparentslab
	2. run query SELECT * FROM customer_orders_fileupload;
Exiting Application:
	Press Ctlr C to stop the server











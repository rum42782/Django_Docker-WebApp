from django.shortcuts import render, redirect
from django.contrib.admin.views.decorators import staff_member_required
from django.core.files.storage import FileSystemStorage
from django.http import HttpResponse
import pandas as pd
from .models import FileUpload
from io import BytesIO


# Create your views here.
def index(request):
    return render(request,"index.html")


def upload(request):
    if request.method == 'POST'and 'file' in request.FILES:
        uploaded_file = request.FILES['file']
        file_extension = uploaded_file.name.split('.')[-1].lower()
        if file_extension != 'xlsx' and file_extension != 'xls':
            error_message = 'Only Excel files (XLSX or XLS) are allowed.'
            return render(request, 'fileupload.html', {'something': False, 'error_message': error_message})
        fs = FileSystemStorage()
        fs.save(uploaded_file.name, uploaded_file)


        try:
            try:
                df = pd.read_excel(uploaded_file, engine='openpyxl')
            except pd.errors.ParserError:
                df = pd.read_excel(uploaded_file, engine='xlrd')

        # Define the expected data types for each attribute

            expected_columns = ['product_name', 'product_price', 'shipped']
            if set(df.columns) != set(expected_columns):
                error_message = 'Invalid columns in the Excel file.'
                return render(request, 'fileupload.html', {'something': False, 'error_message': error_message})

            
        # Insert valid data into the database
            for _, row in df.iterrows():
                shipped_value = str(row['shipped']).strip().lower()
                if shipped_value == 'true':
                    shipped = True
                elif shipped_value == 'false':
                    shipped = False
                else:
                    error_message = 'Invalid value for "shipped" field'
                    return render(request, 'fileupload.html', {'something': False}, {'error_message': error_message})
                file_data = FileUpload(
                    product_name = row['product_name'],
                    product_price = row['product_price'],
                    shipped = shipped
                )
                file_data.save()

            return render(request, 'fileupload.html', {'something': True})
        except pd.errors.ParserError:
            error_message = 'Please upload a valid Excel file'
            return render(request, 'fileupload.html',{'something': False}, {'error_message': error_message})

        

    





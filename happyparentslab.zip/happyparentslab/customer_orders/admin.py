from django.contrib import admin
from django.http import HttpResponse
import pandas as pd
from .models import FileUpload
import io

@admin.register(FileUpload)
class FileUploadAdmin(admin.ModelAdmin):
    list_display = ('product_name', 'product_price', 'shipped')
    actions = ['download_data']

    def download_data(self, request, queryset):
        # Retrieve the data from the queryset
        data = list(queryset.order_by('pk').values())

        # Create a DataFrame from the data
        df = pd.DataFrame(data)

        # Create a BytesIO object to store the Excel file in memory
        excel_file = io.BytesIO()

        # Convert DataFrame to Excel file
        df.to_excel(excel_file,index=False)

        # Set the BytesIO object's position to the beginning
        excel_file.seek(0)

        # Prepare the response with the Excel file
        response = HttpResponse(content_type='application/vnd.ms-excel')
        response['Content-Disposition'] = 'attachment; filename=data.xlsx'
        response.write(excel_file.getvalue())

        return response

    download_data.short_description = 'Download Data'
